import styles from "./navigation.module.css";

const Navigation = () => {
  console.log(styles);
  return (
    <nav className="conainer">
      <div className="log">
        <img src="/images/logo.png" alt="do some coding" />
      </div>
      <ul>
        <li>Home</li>
        <li>About</li>
        <li>Contact Us</li>
      </ul>
    </nav>
  );
};

export default Navigation;
