import Styles from "./contactform.module.css";
import Button from "../Button/Button";
import { MdMessage, MdCall, MdMailOutline } from "react-icons/md";

const Contactform = () => {
  console.log(Styles);
  return (
    <section className={Styles.container}>
      <div className={Styles.contact_form}>
        <div className={Styles.top_btn}>
          <Button
            text="VIA SUPPORT CHAT"
            icon={<MdMessage fontSize="24px" />}
          />
          <Button text="VIA CALL" icon={<MdCall fontSize="24px" />} />
        </div>
        <Button
          isOutline={true}
          text="VIA EMAIL FORM"
          icon={<MdMailOutline fontSize="24px" />}
        />

        <form className={Styles.form}>
          <div className={Styles.form_control}>
            <label htmlFor="name">Name</label>
            <input type="text" name="name" />
          </div>
          <div className={Styles.form_control}>
            <label htmlFor="email">E-Mail</label>
            <input type="email" name="email" />
          </div>
          <div className={Styles.form_control}>
            <label htmlFor="text">text</label>
            <textarea type="text" name="text" rows="7" />
          </div>
          <div
            style={{
              display: "flex",
              justifyContent: "end",
            }}
          >
            <Button text="SUBMIT BUTTON" />
          </div>
        </form>
      </div>
      <div className={Styles.contact_image}>
              <img src="/images/contact.svg" alt="conatct images" />
      </div>
    </section>
  );
};

export default Contactform;
