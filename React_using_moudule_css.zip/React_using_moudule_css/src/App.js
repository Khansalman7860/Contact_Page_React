import "./App.css";
import Navigation from "./components/navigation/navigation";
import ContactHeader from "./components/ContactHeader/ContactHeader"
import Contactform from "./components/ContactForm/contactform";
function App() {
  return (
    <div className="App">
      <Navigation />
      <main className="main_container">
        <ContactHeader />
        <Contactform />
      </main>
    </div>
  );
}

export default App;
